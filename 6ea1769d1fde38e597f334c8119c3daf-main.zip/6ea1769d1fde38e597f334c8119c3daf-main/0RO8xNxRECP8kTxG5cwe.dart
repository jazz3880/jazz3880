import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      title: 'MyApp Demo',
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: WebSite(),
      ),
    );
  }
}

class WebSite extends StatelessWidget {
  const WebSite({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 1440,
      height: 1024,
      clipBehavior: Clip.hardEdge,
      decoration: const BoxDecoration(
        color: Colors.white,
      ),
      child: SizedBox(
        width: double.infinity,
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            Positioned(
              left: 0,
              top: 0,
              child: Container(
                width: 1440,
                height: 113,
                clipBehavior: Clip.hardEdge,
                decoration: const BoxDecoration(
                  color: Colors.white,
                ),
              ),
            ),
            Positioned(
              left: 159,
              top: 34,
              child: Text(
                'Home',
                style: GoogleFonts.getFont(
                  'Istok Web',
                  color: Colors.black,
                  fontSize: 30,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Positioned(
              left: 310,
              top: 34,
              child: Text(
                'Shop',
                style: GoogleFonts.getFont(
                  'Istok Web',
                  color: Colors.black,
                  fontSize: 30,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Positioned(
              left: 451,
              top: 34,
              child: Text(
                'Catalog',
                style: GoogleFonts.getFont(
                  'Istok Web',
                  color: Colors.black,
                  fontSize: 30,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Positioned(
              left: 629,
              top: 34,
              child: Text(
                'Learn',
                style: GoogleFonts.getFont(
                  'Istok Web',
                  color: Colors.black,
                  fontSize: 30,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Positioned(
              left: 19,
              top: 9,
              child: Image.network(
                'https://firebasestorage.googleapis.com/v0/b/codeless-app.appspot.com/o/projects%2FbCIeS54q5MlFU8lDqttP%2F001f68f64d2e8b994a58f59e605308b9f5ce929bRectangle%202.png?alt=media&token=94051827-ec48-4c06-858b-ba22c1e88000',
                width: 98,
                height: 98,
                fit: BoxFit.cover,
              ),
            ),
            Positioned(
              left: 779,
              top: 27,
              child: Container(
                width: 574,
                height: 63,
                clipBehavior: Clip.hardEdge,
                decoration: BoxDecoration(
                  color: const Color(0xFF0D0000),
                  border: Border.all(
                    width: 3,
                    color: const Color(0xFFE3E3E3),
                  ),
                  borderRadius: BorderRadius.circular(40),
                ),
              ),
            ),
            Positioned(
              left: 829,
              top: 43,
              child: Text(
                'Search here',
                style: GoogleFonts.getFont(
                  'Istok Web',
                  color: const Color(0xFFF4F4F4),
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Positioned(
              left: 1214,
              top: 30,
              child: Container(
                width: 139,
                height: 57,
                clipBehavior: Clip.hardEdge,
                decoration: BoxDecoration(
                  color: const Color(0xFFF2F2F2),
                  borderRadius: BorderRadius.circular(40),
                ),
              ),
            ),
            Positioned(
              left: 1242,
              top: 39,
              child: Text(
                'Search',
                style: GoogleFonts.getFont(
                  'Istok Web',
                  color: Colors.black,
                  fontSize: 25,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Positioned(
              left: 106,
              top: 175,
              child: Container(
                width: 358,
                height: 358,
                clipBehavior: Clip.hardEdge,
                decoration: BoxDecoration(
                  color: const Color(0xFFD9D9D9),
                  borderRadius: BorderRadius.circular(40),
                ),
              ),
            ),
            Positioned(
              left: 976,
              top: 175,
              child: Container(
                width: 358,
                height: 358,
                clipBehavior: Clip.hardEdge,
                decoration: BoxDecoration(
                  color: const Color(0xFFD9D9D9),
                  borderRadius: BorderRadius.circular(40),
                ),
              ),
            ),
            Positioned(
              left: 541,
              top: 175,
              child: Container(
                width: 358,
                height: 358,
                clipBehavior: Clip.hardEdge,
                decoration: BoxDecoration(
                  color: const Color(0xFFD9D9D9),
                  borderRadius: BorderRadius.circular(40),
                ),
              ),
            ),
            Positioned(
              left: 106,
              top: 595,
              child: Container(
                width: 358,
                height: 358,
                clipBehavior: Clip.hardEdge,
                decoration: BoxDecoration(
                  color: const Color(0xFFD9D9D9),
                  borderRadius: BorderRadius.circular(40),
                ),
              ),
            ),
            Positioned(
              left: 976,
              top: 595,
              child: Container(
                width: 358,
                height: 358,
                clipBehavior: Clip.hardEdge,
                decoration: BoxDecoration(
                  color: const Color(0xFFD9D9D9),
                  borderRadius: BorderRadius.circular(40),
                ),
              ),
            ),
            Positioned(
              left: 541,
              top: 595,
              child: Container(
                width: 358,
                height: 358,
                clipBehavior: Clip.hardEdge,
                decoration: BoxDecoration(
                  color: const Color(0xFFD9D9D9),
                  borderRadius: BorderRadius.circular(40),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
